# -*- coding: utf-8 -*-
from resources.lib.routing import ROUTER
import sys

ROUTER.initialize(sys.argv)
ROUTER.route()



